# -*- coding:utf-8 -*-

import arcpy
import shutil
import os
import argparse
import time

TempClippedImageFold = r"D:\ClipAndMosicTest\Temp"
ExportImageFold = r"D:\ClipAndMosicTest\Result"


def ClipAndMosic():
    parser = argparse.ArgumentParser(description='manual to this script')
    parser.add_argument('-r', '--Range', type=str, default=None, help='eg: Xmin;Xmax;Ymin;Ymax')
    parser.add_argument('-p', '--Polygon', type=str, default=None, help='eg: 1 for polygon 0 for Rectangle')
    parser.add_argument('-f', '--SourceImageFold', type=str, default=None, help='eg:the fold of image need to clipped')
    parser.add_argument('-o', '--OutputName', type=str, default=None, help='eg: Image1.tif;Image2.tif')
    args = parser.parse_args()

    clippedrangetag = args.Polygon
    sourceimages_fold = args.SourceImageFold
    result_tif_name = args.OutputName
    clipped_range = args.Range

    sourceimages = []
    files = os.listdir(sourceimages_fold)
    for f in files:
        npath = sourceimages_fold + '/' + f
        if os.path.isfile(npath):
            if str(f).lower().endswith("tif") | str(f).lower().endswith("img"):
                sourceimages.append(npath)

    print "===========this is argument============="
    print "Range : ", clipped_range
    print "SourceImagesFold : ", sourceimages_fold
    print "SourceImages : ", sourceimages
    print "ResultName : ", result_tif_name
    print "Py path", os.path.realpath(__file__)

    index = 0
    clipped_image = []

    if os.path.exists(TempClippedImageFold):
        shutil.rmtree(TempClippedImageFold)
    try:
        os.makedirs(TempClippedImageFold)
    except Exception, e:
        os.makedirs(TempClippedImageFold)

    if os.path.exists(ExportImageFold):
        shutil.rmtree(ExportImageFold)
    try:
        os.makedirs(ExportImageFold)
    except Exception, e:
        os.makedirs(ExportImageFold)

    str_export_result_file_path = os.path.join(ExportImageFold, result_tif_name)

    print "===========prepare over , start to clip==========="
    std_image_path = sourceimages[0].replace('\\\\', '\\')
    print "[Properties] : ", std_image_path
    band_number = arcpy.GetRasterProperties_management(std_image_path, "BANDCOUNT").getOutput(0)
    print "this bandnumer of first Image :  ", band_number
    pixel_depth = arcpy.GetRasterProperties_management(std_image_path, "VALUETYPE").getOutput(0)
    print "this pixel depth of first Image :  ", convertValueTypeToPix(pixel_depth)

    if clippedrangetag == str(0):
        start = time.clock()
        print "===========Clip by Rectangle==========="
        # clipped_range = " ".join(clipped_range)
        clipped_range = " ".join(readrangestr(clipped_range).split(';'))
        print "[Clipp Range] : ", clipped_range
        for src_image in sourceimages:
            src_image = src_image.replace('\\\\', '\\')
            if src_image.strip() != '':
                spatial_name = arcpy.Describe(src_image).spatialReference.Name
                if spatial_name == "Unknown":
                    print "define project to ", src_image
                    try:
                        arcpy.DefineProjection_management(src_image, arcpy.SpatialReference(4508))
                    except arcpy.ExecuteError:
                        print "===========Can not define project==========="
                else:
                    print "[Properties] : spatial_name is :", spatial_name
                print "[Clipp src] : ", src_image
                if src_image.lower().endswith(".img"):
                    temp_clip_name = TempClippedImageFold + r"\Temp" + str(index) + ".img"
                else:
                    temp_clip_name = TempClippedImageFold + r"\Temp" + str(index) + ".tif"
                arcpy.Clip_management(src_image, clipped_range, temp_clip_name)
                clipped_image.append(temp_clip_name)
                index = index + 1
                print "[Clipp result] : ", temp_clip_name
        end = time.clock()
        print "=========== clipped over , processing time", end - start, " start to Mosaic"

        start = time.clock()
        clip_result = ";".join(clipped_image)
        print "[Start to Mosaic]: ", clip_result
        arcpy.MosaicToNewRaster_management(clip_result, ExportImageFold, result_tif_name,
                                           number_of_bands=band_number, mosaic_method="LAST",
                                           mosaic_colormap_mode="FIRST", pixel_type=convertValueTypeToPix(pixel_depth))
        end = time.clock()
        print "=========== mosaicToNewRaster success , processing time", end - start
        print "&Success&", ExportImageFold
    else:
        start = time.clock()
        print "=========== Clip by Polygon==========="
        # 0. read rangestr from file
        tem_range_str = readrangestr(clipped_range)
        print tem_range_str
        # 1. write json string to jsonfile in tempFold
        temp_json_filename = TempClippedImageFold + r"/Clipped.json"
        with open(temp_json_filename, 'w') as f:  # 设置文件对象
            f.write(convertToJson(tem_range_str))
        # 2. create clip mulitpolygon by jsonfile
        temp_multi_filename = TempClippedImageFold + r"/TempRange.shp"
        arcpy.JSONToFeatures_conversion(in_json_file=temp_json_filename, out_features=temp_multi_filename)
        # 3. repair geomtry
        arcpy.RepairGeometry_management(temp_multi_filename, delete_null="DELETE_NULL")
        # 4. use 'ExtractbyMask' to extract image to tempImage
        for src_image in sourceimages:
            src_image = src_image.replace('\\\\', '\\')
            if src_image.strip() != '':
                spatial_name = arcpy.Describe(src_image).spatialReference.Name
                if spatial_name == "Unknown":
                    print "define project to ", src_image
                    try:
                        arcpy.DefineProjection_management(src_image, arcpy.SpatialReference(4508))
                    except arcpy.ExecuteError:
                        print "=========== Can not define project ==========="
                else:
                    print "[Properties] : spatial_name is :", spatial_name
                print "[Clipp src] : ", src_image
                if src_image.lower().endswith(".img"):
                    temp_clip_name = TempClippedImageFold + r"\Temp" + str(index) + ".img"
                else:
                    temp_clip_name = TempClippedImageFold + r"\Temp" + str(index) + ".tif"
                arcpy.gp.ExtractByMask_sa(src_image, temp_multi_filename, temp_clip_name)
                clipped_image.append(temp_clip_name)
                index = index + 1
                print "[Clipp result] : ", temp_clip_name
        # 4. mosiac tempImage to tempResult
        clip_result = ";".join(clipped_image)
        print "[Start to Mosaic]: ", clip_result
        arcpy.MosaicToNewRaster_management(clip_result, ExportImageFold, result_tif_name,
                                           number_of_bands=band_number, mosaic_method="LAST",
                                           mosaic_colormap_mode="FIRST", pixel_type=convertValueTypeToPix(pixel_depth))
        end = time.clock()
        print "=========== mosaicToNewRaster success , processing time ", end - start
        print "&Success&", ExportImageFold


def convertToJson(points_str):
    jsonstr = []
    jsonstr.append("{")
    jsonstr.append("$displayFieldName$:$$,$fieldAliases$:{$FID$:$FID$,$Id$:$Id$,$WKT$:$WKT$},")
    jsonstr.append("$geometryType$:$esriGeometryPolygon$,$spatialReference$:{$wkid$ : 4508,$latestWkid$:4508},")
    jsonstr.append("$fields$:[{$name$:$FID$,$type$:$esriFieldTypeOID$,$alias$:$FID$},{$name$:$Id$,$type$:$esriFieldTypeInteger$,$alias$:$Id$},{$name$:$WKT$,$type$:$esriFieldTypeString$,$alias$:$WKT$,$length$:50}],")
    jsonstr.append("$features$:[{$attributes$:{$FID$:0,$Id$:0,$WKT$:$$},")
    jsonstr.append("$geometry$:{$rings$:[")
    temp1 = []
    for ring in points_str.split('&'):
        if ring.strip() != '':
            temp2 = []
            for point in ring.split(';'):
                if point.strip() != '':
                    x, y = point.split(',')
                    temp2.append("[{0},{1}]".format(str(x), str(y)))
            # print ",".join(temp2)
            temp1.append("[" + ",".join(temp2) + "]")
    # print ",".join(temp1)
    jsonstr.append(",".join(temp1))
    jsonstr.append("]}}]}")

    return "".join(jsonstr).replace("$", "\"")


def convertValueTypeToPix(valuetype):
    if valuetype == '0':
        return "1_BIT"
    elif valuetype == '1':
        return "2_BIT"
    elif valuetype == '2':
        return "4_BIT"
    elif valuetype == '3':
        return "8_BIT_UNSIGNED"
    elif valuetype == '4':
        return "8_BIT_SIGNED"
    elif valuetype == '5':
        return "16_BIT_UNSIGNED"
    elif valuetype == '6':
        return "16_BIT_SIGNED"
    elif valuetype == '7':
        return "32_BIT_UNSIGNED"
    elif valuetype == '8':
        return "32_BIT_SIGNED"
    elif valuetype == '9':
        return "32_BIT_FLOAT"
    elif valuetype == '10':
        return "64_BIT"
    else:
        return "8_BIT_UNSIGNED"

def readrangestr(str_rangefile_path):
    with open(str_rangefile_path, 'r') as f:  # 设置文件对象
        temprangestr = f.read()
    return temprangestr


if __name__ == '__main__':
    try:
        arcpy.CheckOutExtension("Spatial")
        ClipAndMosic()
    except Exception, e:
        print "%Fail%", str(e)

