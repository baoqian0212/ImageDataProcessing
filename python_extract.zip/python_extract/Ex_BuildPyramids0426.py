import arcpy
import shutil
import os
import sys
import argparse
import datetime


compression_type = "JPEG" # other value can use "DEFAULT" "LZ77" "NONE"
compression_quality = "50"

def BuildPyramids():
    parser = argparse.ArgumentParser(description='manual to this script')
    parser.add_argument('-S','--SourceImage', type=str, default=None,help='eg: sample.tif' )
    parser.add_argument('-L','--Level', type=str, default=5,help='eg: -1 for build all level; max level is 29;0 for delete pyramids' )
    args = parser.parse_args()
    SourceImage = args.SourceImage;
    Level = args.Level;
    
    ImageType = "IMG"
    if SourceImage.upper().endswith("IMG"):
        ImageType = "IMG"
    else:
        ImageType = "Un IMG"

    if str(Level).strip() == '':
        Level = 10

    print "===========this is argument============="
    print "SourceImages : " , SourceImage
    print "Level : " , Level
    print "ImageType : ",ImageType


    PyramidPath = []
    SourceImages = SourceImage.split(";")
    start = time.clock()
    print "===========prepare to Build==========="
    if ImageType != "IMG":
        for str_Image in SourceImages:
            if str_Image.strip() != '':
                arcpy.BuildPyramids_management(str_Image,Level, compression_type = compression_type, compression_quality = compression_quality)
                PyramidPath.append("{0}.ovr".format(str_Image))
                print "[Build Done] : {0}".format(str_Image)
        end = time.clock()
        print "=========== Build processing time : ", end - start
        print "&Success&" , ";".join(PyramidPath)
    else:
        for str_Image in SourceImages:
            if str_Image.strip() != '':
                arcpy.BuildPyramids_management(str_Image,Level)
                PyramidPath.append("{0}.rrd".format(str_Image))
                print "[Build Done] : {0}".format(str_Image)
        end = time.clock()
        print "=========== Build processing time : ", end - start
        print "&Success&" , ";".join(PyramidPath)
    
    
if __name__ == '__main__':
    try:
        BuildPyramids()
    except arcpy.ExecuteError:
        print "%Fail%"  ,str(arcpy.GetMessages(2))
    except Exception, e:
        print "%Fail%"  ,str(e)
