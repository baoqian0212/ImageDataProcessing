# -*- coding:utf-8 -*-

import arcpy
import shutil
import os
import argparse
import time

TempClippedImageFold = r"D:\ClipAndMosicTest\Temp"
ExportImageFold = r"D:\ClipAndMosicTest\Result"


def ClipAndMosic():
    parser = argparse.ArgumentParser(description='manual to this script')
    parser.add_argument('-r', '--Range', type=str, default=None, help='eg: Xmin;Xmax;Ymin;Ymax')
    parser.add_argument('-p', '--Polygon', type=str, default=None, help='eg: 1 for polygon 0 for Rectangle')

    #modify 新增
    parser.add_argument('-f', '--SourceImageFold', type=str, default=None, help='eg: Image1.tif;Image2.tif')
    #modeify end
    
    parser.add_argument('-o', '--OutputName', type=str, default=None, help='eg: Image1.tif;Image2.tif')
    args = parser.parse_args()

    clippedrangetag = args.Polygon
    
    #modify 新增
    sourceimages_fold = args.SourceImageFold
    #modeify end
    
    clipped_range = args.Range.split(";")
    result_tif_name = args.OutputName

    if len(clipped_range) >= 1000:
        raise Exception, "vertices need less than 1000!"

    #modify 新增
    sourceimages = []
    files = os.listdir(sourceimages_fold)
    for f in files:
        npath = sourceimages_fold + '/' + f
        if os.path.isfile(npath):
            if str(f).lower().endswith("tif") | str(f).lower().endswith("img"):
                sourceimages.append(npath)
    #modeify end


    print "===========this is argument============="
    print "Range : ", clipped_range

    #modify
    print "sourceimagesFold : ", sourceimages_fold
    #modeify end
    
    print "SourceImages : ", sourceimages
    print "ResultName : ", result_tif_name

    #modify
    print "py path", os.path.realpath(__file__)
    #modeify end

    index = 0
    clipped_image = []

    if os.path.exists(TempClippedImageFold):
        shutil.rmtree(TempClippedImageFold)
    try:
        os.makedirs(TempClippedImageFold)
    except Exception, e:
        os.makedirs(TempClippedImageFold)

    if os.path.exists(ExportImageFold):
        shutil.rmtree(ExportImageFold)
    try:
        os.makedirs(ExportImageFold)
    except Exception, e:
        os.makedirs(ExportImageFold)

    str_export_result_file_path = os.path.join(ExportImageFold, result_tif_name)

    print "===========prepare over , start to clip==========="
    std_image_path = sourceimages[0].replace('\\\\', '\\')
    print "[Properties] : ", std_image_path
    band_number = arcpy.GetRasterProperties_management(std_image_path, "BANDCOUNT").getOutput(0)
    print "this bandnumer of first Image :  ", band_number

    if clippedrangetag == str(0):
        start = time.clock()
        print "===========Clip by Rectangle==========="
        clipped_range = " ".join(clipped_range)
        for src_image in sourceimages:
            src_image = src_image.replace('\\\\', '\\')

            # modify 新增
            if src_image.strip() != '':
                spatial_name = arcpy.Describe(src_image).spatialReference.Name
                if spatial_name == "Unknown":
                    print "define project to ", src_image
                    try:
                        arcpy.DefineProjection_management(src_image, arcpy.SpatialReference(4508))
                    except arcpy.ExecuteError:
                        print "===========Can not define project==========="
                else:
                    print "[Properties] : spatial_name is :", spatial_name
            
             #modeify end
                   
                            
                print "[Clipp src] : ", src_image
                temp_clip_name = TempClippedImageFold + r"\Temp" + str(index)
                arcpy.Clip_management(src_image, clipped_range, temp_clip_name)
                clipped_image.append(temp_clip_name)
                index = index + 1
                print "[Clipp result] : ", temp_clip_name
        end = time.clock()
        print "=========== clipped over , processing time", end - start, " start to Mosaic"

        start = time.clock()
        str_clip_result = ";".join(clipped_image)
        arcpy.MosaicToNewRaster_management(str_clip_result, ExportImageFold, result_tif_name, number_of_bands=band_number,
                                           mosaic_method="BLEND", mosaic_colormap_mode="MATCH")
        end = time.clock()
        print "=========== mosaicToNewRaster success , processing time", end - start
        print "&Success&", ExportImageFold
    else:
        start = time.clock()
        print "=========== Clip by Polygon==========="
        poly_points = []
        x_set = []
        y_set = []
        for point in clipped_range:
            if point.strip() != '':
                x, y = point.split(',')
                poly_points.append("\'{0} {1}\'".format(str(x), str(y)))
                x_set.append(x)
                y_set.append(y)
        x_min = str(min(x_set)); x_max = str(max(x_set)); y_min = str(min(y_set)); y_max = str(max(y_set))
        str_polypoints = ";".join(poly_points)
        print str_polypoints
        for src_image in sourceimages:
            src_image = src_image.replace('\\\\', '\\')

            # modify 新增
            if src_image.strip() != '':
                spatial_name = arcpy.Describe(src_image).spatialReference.Name
                if spatial_name == "Unknown":
                    print "define project to ", src_image
                    try:
                        arcpy.DefineProjection_management(src_image, arcpy.SpatialReference(4508))
                    except arcpy.ExecuteError:
                        print "===========Can not define project==========="
                else:
                    print "[Properties] : spatial_name is :", spatial_name
            
             #modeify end
            
                print "[Clipp src] : ", src_image
                tempclipname = TempClippedImageFold + r"\Temp" + str(index)
	        arcpy.gp.ExtractByPolygon_sa(src_image, str_polypoints, tempclipname, "INSIDE")
             #   arcpy.sa.ExtractByPolygon(src_image, str_polypoints, tempclipname, "INSIDE")
                clipped_image.append(tempclipname)
                index = index + 1
                print "[Clipp result] : ", tempclipname
                
        end = time.clock()
        print "=========== clipped over , processing time", end - start, " start to Mosaic"

        start = time.clock()
        str_clip_result = ";".join(clipped_image)
        str_mosaic_file_name = os.path.join(TempClippedImageFold, "MosaicResult.tif");
        arcpy.MosaicToNewRaster_management(str_clip_result, TempClippedImageFold, "MosaicResult.tif",
                                           number_of_bands=band_number, mosaic_method="BLEND",
                                           mosaic_colormap_mode="MATCH")
        str_mask_range = " ".join((x_min, y_min, x_max, y_max))
        arcpy.Clip_management(str_mosaic_file_name, str_mask_range, str_export_result_file_path)
        end = time.clock()
        print "=========== mosaicToNewRaster success , processing time ", end - start
        print "&Success&", ExportImageFold

        del x_set
        del y_set


if __name__ == '__main__':
    try:
        arcpy.CheckOutExtension("Spatial")
        ClipAndMosic()
    except Exception, e:
        print "%Fail%", str(e)

